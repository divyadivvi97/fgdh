package com.capgemini.employeeapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.employeeapp.dto.Employee;
import com.capgemini.employeeapp.exception.EmployeeException;
import com.capgemini.employeeapp.service.EmployeeService;



@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeservice;
	@RequestMapping("/")
public ModelAndView showIndex()
{
	ModelAndView mv= new ModelAndView("index");
	try {
		List<Employee> employees=employeeservice.getEmployees();
		mv.addObject("employees", employees);
	} catch (EmployeeException e) {
		
		e.printStackTrace();
	}
	return mv;
}
	@RequestMapping("/addEmployee")
	public String showAdd(Model model)
	{
		model.addAttribute("employee", new Employee());
		return "add";
	}
	@RequestMapping("/add")
	public  ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result)
	{ String a="";
		ModelAndView mv=null;
		if(result.hasErrors()){
			 mv=new ModelAndView("add");
		mv.addObject("employee", employee);
	      }
	else
	{
		
		try {
			 a=employeeservice.addEmployee(employee);
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
			
		}
	}
	return new ModelAndView("success","success",a);
}
	@RequestMapping("/home")
	public void Admin(){
		try {
			employeeservice.Admin();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
