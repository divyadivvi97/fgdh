package com.capgemini.employeeapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin_product")
public class Admin {
	@Id
	@Column(name="product_Id")
	private int productId;
	@Column(name="product_Name")
	private  String product_Name;
	private  String product_Description;
	private String  product_Category;
	private double product_price;
	private int Quantity;
	@Column(name="seller_email_Id")
	private String seller_emailId;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public String getProduct_Description() {
		return product_Description;
	}
	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}
	public String getProduct_Category() {
		return product_Category;
	}
	public void setProduct_Category(String product_Category) {
		this.product_Category = product_Category;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String getSeller_emailId() {
		return seller_emailId;
	}
	public void setSeller_emailId(String seller_emailId) {
		this.seller_emailId = seller_emailId;
	}
	public Admin(int productId, String product_Name,
			String product_Description, String product_Category,
			double product_price, int quantity, String seller_emailId) {
		super();
		this.productId = productId;
		this.product_Name = product_Name;
		this.product_Description = product_Description;
		this.product_Category = product_Category;
		this.product_price = product_price;
		Quantity = quantity;
		this.seller_emailId = seller_emailId;
	}
	public Admin() {
		super();
	}
	@Override
	public String toString() {
		return "Admin [productId=" + productId + ", product_Name="
				+ product_Name + ", product_Description=" + product_Description
				+ ", product_Category=" + product_Category + ", product_price="
				+ product_price + ", Quantity=" + Quantity
				+ ", seller_emailId=" + seller_emailId + "]";
	}
	
}
