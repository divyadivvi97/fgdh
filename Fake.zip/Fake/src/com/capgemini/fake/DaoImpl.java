package com.capgemini.fake;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


//import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
@Transactional
public class DaoImpl implements IDao{
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public Cart updateCart(Integer productId, String emailId) {
		Cart c=new Cart();
		
		// TODO Auto-generated method stub
		Product product=entityManager.find(Product.class,productId);
		c.setProductId(product.getProductId());
		c.setProductName(product.getProductName());
		c.setCustomeremailId(emailId);
		c.setProductCategory(product.getProductCategory());
		c.setProductPrice(product.getProductPrice());
		c.setProductDescription(product.getProductDescription());
		c.setProductQuantity(product.getProductQuantity());
		System.out.println(c.getCartId());
		
		entityManager.merge(c);
		return c;
	}


	@Override
	public void removeItemFromTheCart(Integer cartId) {
		// TODO Auto-generated method stub
		Cart cart=entityManager.find(Cart.class,cartId);
		entityManager.remove(cart);
		
	}

}
